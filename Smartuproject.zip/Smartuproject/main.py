import pdfplumber
import nltk
from heapq import nlargest
from langdetect import detect
from nltk.tokenize import word_tokenize, sent_tokenize
from collections import Counter
import re

# Download necessary resources
nltk.download('punkt')

def extract_text_from_pdf(pdf_path):
    text = ""
    with pdfplumber.open(pdf_path) as pdf:
        for page in pdf.pages:
            page_text = page.extract_text()
            # Remove (cid:...) pattern
            page_text_cleaned = re.sub(r'\(cid:\d+\)', '', page_text)
            text += page_text_cleaned
    return text

def generate_summary(text):
    # Tokenize sentences
    sentences = sent_tokenize(text)

    # Tokenize words
    words = word_tokenize(text)

    # Calculate word frequency
    word_frequencies = Counter(words)

    # Normalize word frequencies
    maximum_frequency = max(word_frequencies.values())
    for word in word_frequencies.keys():
        word_frequencies[word] = word_frequencies[word] / maximum_frequency

    # Calculate sentence scores based on word frequency
    sentence_scores = {}
    for sentence in sentences:
        for word in word_tokenize(sentence):
            if word in word_frequencies.keys():
                if len(sentence.split(' ')) < 30:
                    if sentence not in sentence_scores:
                        sentence_scores[sentence] = word_frequencies[word]
                    else:
                        sentence_scores[sentence] += word_frequencies[word]

    # Select top N sentences for summary
    num_sentences = 50  # Number of sentences for summary
    summary_sentences = nlargest(num_sentences, sentence_scores, key=sentence_scores.get)
    summary = ' '.join(summary_sentences)

    return summary

def main():
    # Replace 'path_to_your_pdf.pdf' with the actual path to your PDF file
    pdf_path = 'risk research paper.pdf'

    # Extract text from the PDF
    pdf_text = extract_text_from_pdf(pdf_path)

    # Generate summary
    summary = generate_summary(pdf_text)

    # Print the summary
    print("Summary:")
    print(summary)

if __name__ == "__main__":
    main()
